default[:firewall][:rules] = []
default[:firewall][:securitylevel] = ""
